%% TASK 4

clear
close all
load A1_data.mat

lambda_1 = 0.1;
lambda_2 = 10;
lambda_user = 1;

w_hat1 = skeleton_lasso_ccd(t, X, lambda_1);
w_hat2 = skeleton_lasso_ccd(t, X, lambda_2);
w_hatuser = skeleton_lasso_ccd(t, X, lambda_user);

y_hat1 = Xinterp * w_hat1;
y_hat2 = Xinterp * w_hat2;
y_hatuser = Xinterp * w_hatuser;

y_1 = X * w_hat1;
y_2 = X * w_hat2;
y_user = X * w_hatuser;

figure
hold on
title('\lambda = 0.1')
scatter(n, t, 40, 'b')
scatter(n, y_1, 40, 'filled')
plot(ninterp, y_hat1, 'r')
legend('Original Data Points', 'Synthesized Data Points', 'Fit')
xlabel('Time')

figure
hold on
title('\lambda = 10')
scatter(n, t, 40, 'b')
scatter(n, y_2, 40, 'filled')
plot(ninterp, y_hat2, 'r')
legend('Original Data Points', 'Synthesized Data Points', 'Fit')
xlabel('Time')


figure
hold on
title('\lambda = 1')
scatter(n, t, 40, 'b')
scatter(n, y_user, 40, 'filled')
plot(ninterp, y_hatuser, 'r')
legend('Original Data Points', 'Synthesized Data Points', 'Fit')
xlabel('Time')


non_zeros_lambda_1 = sum(w_hat1~=0) % 234
non_zeros_lambda_2 = sum(w_hat2~=0) % 6
non_zeros_lambda_user = sum(w_hatuser~=0) % 62

%% Task 5

clear;
close all
load A1_data.mat

lambda_mini = 0.01;
lambda_maxi = max(abs(X'*t));
K = 5;
nbr_lambdas = 100;
lambda_range = exp( linspace(log(lambda_mini),log(lambda_maxi), nbr_lambdas));

[w_opt, lambda_opt,RMSE_val, RMSE_est] = skeleton_lasso_cv(t, X, lambda_range, K);
t_opt = Xinterp*w_opt;
t_data = X*w_opt;

%% Prints for task 5
plot_handles = [];
figure,
hold on
plot_handles = [plot_handles scatter(log(lambda_range), RMSE_val, 'gx')];
plot(log(lambda_range),RMSE_val,'g');
plot_handles = [plot_handles scatter(log(lambda_range), RMSE_est, 'bx')];
plot(log(lambda_range), RMSE_est,'b');
plot_handles = [plot_handles xline(log(lambda_opt), '--r')];
legend(plot_handles, 'RMSE Validation', 'RMSE Estimation', '\lambda Optimal');
xlabel('log \lambda')
what_opt = skeleton_lasso_ccd(t,X, lambda_opt);
yhat_opt = Xinterp*what_opt;
ydata_opt = X * what_opt;

figure
hold on
scatter(n, t, 30, 'g')
scatter(n, ydata_opt, 30, 'filled')
plot(ninterp, yhat_opt, 'b')
legend('Original Data Points', 'Synthesized Data Points', 'Fit')
xlabel('Time')

%% Task 6 
clear;
close all
load A1_data.mat
%soundsc(Ttrain,fs)
lambda_mini = 1e-3;
nbr_lambdas = 1e2;
nbr_folds = 5;
lambda_maxi=max(abs(X'*t));
lambda_range = exp(linspace(log(lambda_mini),log(lambda_maxi), nbr_lambdas));
[Wopt,lambdaopt,RMSEval,RMSEest] = skeleton_multiframe_lasso_cv(Ttrain,X,lambda_range,nbr_folds);
yopt=X*Wopt;



%% Plotting for task 6
load A1_data.mat

plot_handles = [];
figure,
hold on
plot_handles = [plot_handles scatter(log(lambda_range), RMSEval, 'cx')];
plot(log(lambda_range), RMSEval,'c');
plot_handles = [plot_handles scatter(log(lambda_range), RMSEest, 'bx')];
plot(log(lambda_range),RMSEest,'b');
plot_handles = [plot_handles xline(log(lambdaopt),'--r')];
legend(plot_handles, 'RMSE Validation', 'RMSE Estimation', '\lambda optimal');
xlabel('log lambda')


%% Task 7

load A1_data.mat

y_test = lasso_denoise(Ttest, Xaudio, lambdaopt);
soundsc(y_test,fs);
save('reconstructed_audio','y_test','fs');
